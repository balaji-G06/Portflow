import Home from "@/components/app/page"

export default function Page() {
  return <Home />
} 